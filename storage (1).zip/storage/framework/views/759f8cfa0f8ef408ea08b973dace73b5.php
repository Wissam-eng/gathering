<?php $__env->startSection('content'); ?>
    


    <?php if(session('success')): ?>
        <div
            class="flex items-center p-3.5 rounded text-success bg-success-light dark:bg-success-dark-light text-align-center">
            <?php echo e(session('success')); ?>


        </div>
    <?php endif; ?>




    <?php if(session('error')): ?>
        <div class="flex items-center p-3.5 rounded text-danger bg-danger-light dark:bg-danger-dark-light text-align-center">
            <?php echo e(session('error')); ?>


        </div>
    <?php endif; ?>



    <div class="card">

        <?php $__currentLoopData = $Key_speakerss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- card -->
            <div style="display: flex; flex-direction: column;"
                class="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none card">

                <!-- Header -->
                <div style="    display: flex;     justify-content: space-evenly;"
                    class="flex items-center justify-between py-4 px-6 border-b border-[#e0e6ed] dark:border-[#1b2e4b]">


                    <!-- زر التعديل -->
                    <a href="<?php echo e(route('key_speakers.edit', $item->id)); ?>"
                        class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-600">
                        <i class="fa-regular fa-pen-to-square"></i>
                    </a>


                    <form id="delete-form-<?php echo e($item->id); ?>" action="<?php echo e(route('key_speakers.destroy', $item->id)); ?>"
                        method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                    </form>
                    <!-- زر الحذف -->
                    <a href="javascript:void(0);" onclick="confirmDelete(<?php echo e($item->id); ?>)"
                        class="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-600">
                        <i class="fa-solid fa-trash"></i>
                    </a>


                </div>

                <div class="py-7 px-6">
                    <!-- صورة الكارت -->
                    <div class="-mt-7 mb-7 -mx-6 rounded-tl rounded-tr h-[215px] overflow-hidden">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="image" class="w-full h-full object-cover" />
                    </div>


                    <!-- العنوان -->
                    <h2 class="text-[#3b3f5c] text-lg font-semibold dark:text-white-light">
                        <?php echo e($item->title); ?>

                    </h2>

                    <hr>

                    
                    <!-- العنوان -->
                    <h2 class="text-[#3b3f5c] text-lg font-semibold dark:text-white-light">
                        <?php echo e($item->title); ?>

                    </h2>

                    <hr>



                    <!-- النصوص الأخرى -->
                    <textarea class="text-white-dark fixed-height-textarea" disabled>
                        <?php echo e($item->description); ?>

                    </textarea>
                    <hr>

                    <p class="text-white-dark fixed-height-paragraph">
                        <?php echo e($item->text); ?>

                    </p>


                    <!-- زر تحميل الملف -->
                    <?php if(!empty($item->file)): ?>
                        <a href="<?php echo e(asset($item->file)); ?>" class="mt-4 inline-block text-center" download>
                            <i class="fa-solid fa-download"></i>
                            تحميل الملف
                        </a>
                    <?php else: ?>
                        <p class="text-gray-500 mt-4">لا يوجد ملف متاح.</p>
                    <?php endif; ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


    <style>
        .card {
            display: flex;
            flex-wrap: wrap;
            align-items: stretch;
            justify-content: center;
            gap: 1%;
        }

        textarea {
            border: black 1px solid;
            resize: auto !important;
        }



        .fixed-height-title {
            height: 50px;
            /* الطول الثابت للعناوين */
            line-height: 1.5;
            overflow: hidden;
            /* لإخفاء النصوص الزائدة */
            text-overflow: ellipsis;
            /* لإضافة (...) في نهاية النص إذا تجاوز الطول */
            white-space: nowrap;
            /* يمنع التفاف النص */
        }

        .fixed-height-subtitle {
            height: 40px;
            /* الطول الثابت للعناوين الفرعية */
            line-height: 1.5;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .fixed-height-textarea {
            height: 80px;
            /* الطول الثابت للنصوص الطويلة */
            overflow-y: auto;
            /* يضيف شريط تمرير إذا تجاوز النص الطول */
            resize: none;
            /* يمنع المستخدم من تغيير الحجم يدويًا */
        }

        .fixed-height-paragraph {
            height: 60px;
            /* الطول الثابت للنصوص */
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/highgdpy/public_html/gathering/resources/views/key_speakers/index.blade.php ENDPATH**/ ?>