<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div
            class="flex items-center p-3.5 rounded text-success bg-success-light dark:bg-success-dark-light text-align-center">
            <?php echo e(session('success')); ?>


        </div>
    <?php endif; ?>



    <?php if(session('error')): ?>
        <div class="flex items-center p-3.5 rounded text-danger bg-danger-light dark:bg-danger-dark-light text-align-center">
            <?php echo e(session('error')); ?>


        </div>
    <?php endif; ?>

    <div class="container" style="width: 50%;">

        <!-- form controls -->
        <form class="space-y-5" method="POST" action="<?php echo e(route('update_profile')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>



            

            <input type="hidden" name="id" value="<?php echo e($profile->id); ?>">

            <div style="display: flex;justify-content: center;" class="-mt-7 mb-7 -mx-6 rounded-tl rounded-tr h-[215px] overflow-hidden">
                <img src="<?php echo e($profile->img ? asset($profile->img) : url('resources/views/main/assets/images/user-profile.jpeg')); ?>"
                     alt="image"
                     class=" object-cover" />
            </div>






            <div>
                <label for="ctnEmail">name</label>
                <input type="text" name="name" value="<?php echo e($profile->name); ?>" placeholder="Some Text..." class="form-input"  />
            </div>





            <div>
                <label for="ctnTextarea">email</label>
                <input type="email" name="email" value="<?php echo e($profile->email); ?>" placeholder="Some Text..." class="form-input"  />
            </div>


            <div>
                <label for="ctnTextarea">password</label>
                <input type="text" name="password"  placeholder="if you don't want to change password leave it empty" class="form-input"  />
            </div>


            <div>
                <label for="ctnFile">Upload Imag</label>
                <input id="ctnFile" type="file" name="img"
                    class="form-input file:py-2 file:px-4 file:border-0 file:font-semibold p-0 file:bg-primary/90 ltr:file:mr-5 rtl:file:ml-5 file:text-white file:hover:bg-primary"
                     />
            </div>


            <button type="submit" class="btn btn-primary !mt-6">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/highgdpy/public_html/gathering/resources/views/profile/index.blade.php ENDPATH**/ ?>