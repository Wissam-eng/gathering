<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="flex items-center p-3.5 rounded text-danger bg-danger-light dark:bg-danger-dark-light text-align-center">
            <?php echo e(session('error')); ?>


        </div>
    <?php endif; ?>
    <div class="container" style="width: 50%;">


        <!-- card -->
        <div
            class="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-[#e0e6ed] dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none card">



            <div class="py-7 px-6">
                <!-- صورة الكارت -->
                <div class="-mt-7 mb-7 -mx-6 rounded-tl rounded-tr h-[215px] overflow-hidden">
                    <img src="<?php echo e(asset($card->image)); ?>" alt="image" class="w-full h-full object-cover" />
                </div>


                <!-- العنوان -->
                <h2 class="text-[#3b3f5c] text-lg font-semibold dark:text-white-light">
                    <?php echo e($card->title); ?>

                </h2>

                <hr>

                <!-- العنوان الفرعي -->
                <h5 class="text-[#3b3f5c] text-lg font-semibold mb-4 dark:text-white-light fixed-height-subtitle">
                    <?php echo e($card->address); ?>

                </h5>
                <hr>

                <h5 class="text-[#3b3f5c] text-lg font-semibold mb-4 dark:text-white-light fixed-height-subtitle">
                    <?php echo e($card->date); ?>

                </h5>
                <hr>

                <!-- النصوص الأخرى -->
                <textarea class="text-white-dark fixed-height-textarea" disabled>
                            <?php echo e($card->description); ?>

                </textarea>
                <hr>

                <p class="text-white-dark fixed-height-paragraph">
                    <?php echo e($card->text); ?>

                </p>
            </div>
        </div>

        <!-- form controls -->
        <form class="space-y-5" method="POST" action="<?php echo e(route('main.update', $card)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label for="ctnEmail">Title</label>
                <input type="text" name="title" value="<?php echo e($card->title); ?>" placeholder="Some Text..."
                    class="form-input" required />
            </div>

            <div>
                <label for="ctnEmail">Address</label>
                <input type="text" name="address" value="<?php echo e($card->address); ?>" placeholder="Some Text..."
                    class="form-input" required />
            </div>



            <!-- basic -->
            <div x-data="form">
                <input id="basic" type="text" value="<?php echo e($card->date); ?>" x-model="date1" class="form-input" />
            </div>




            <div>
                <label for="ctnTextarea">Description</label>
                <textarea id="ctnTextarea" rows="3" name="description" class="form-textarea" placeholder="Description" required> <?php echo e($card->description); ?></textarea>
            </div>
            <div>
                <label for="ctnFile">Upload Imag</label>
                <input id="ctnFile" type="file" name="image"
                    class="form-input file:py-2 file:px-4 file:border-0 file:font-semibold p-0 file:bg-primary/90 ltr:file:mr-5 rtl:file:ml-5 file:text-white file:hover:bg-primary" />
            </div>
            <button type="submit" class="btn btn-primary !mt-6">update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/highgdpy/public_html/gathering/resources/views/main/edite.blade.php ENDPATH**/ ?>